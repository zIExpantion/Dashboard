import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

interface RisikoEintrag {
  kriterium: string;
  punkte: number;
}

interface Lieferant {
  name: string;
  produkt: string;
  risiko: number;
  geodaten: string;
  land: string;
  kontinent: string;
  zertifikat: boolean;
  benutzerRisiken?: RisikoEintrag[];
}

const vorgefertigteRisiken: RisikoEintrag[] = [
  { kriterium: "Keine Satellitendaten verfügbar", punkte: 15 },
  { kriterium: "Fehlende Lieferkettentransparenz", punkte: 20 },
  { kriterium: "Unbekannter Herkunftsnachweis", punkte: 25 },
];

const lieferanten: Lieferant[] = [
  { name: "KaffeeCo Brasilien", produkt: "Kaffee", risiko: 85, geodaten: "-10.333, -45.667", land: "Brasilien", kontinent: "Südamerika", zertifikat: false, benutzerRisiken: [] },
  { name: "ChocoTrade Ghana", produkt: "Schokolade", risiko: 75, geodaten: "7.9465, -1.0232", land: "Ghana", kontinent: "Afrika", zertifikat: true, benutzerRisiken: [] },
  { name: "BeefExport Argentinien", produkt: "Rindfleisch", risiko: 92, geodaten: "-38.4161, -63.6167", land: "Argentinien", kontinent: "Südamerika", zertifikat: false, benutzerRisiken: [] },
  { name: "PapierMüller DE", produkt: "Papier", risiko: 20, geodaten: "51.1657, 10.4515", land: "Deutschland", kontinent: "Europa", zertifikat: true, benutzerRisiken: [] },
];

function berechneRisiko(lieferant: Lieferant) {
  let punkte = 0;
  const details: RisikoEintrag[] = [];

  const hochrisikoLaender = ["Brasilien", "Indonesien", "Argentinien", "Kongo"];
  const hochrisikoProdukte = ["Rindfleisch", "Kaffee", "Kakao", "Palmöl"];

  if (hochrisikoLaender.includes(lieferant.land)) {
    punkte += 40;
    details.push({ kriterium: "Herkunftsland ist Hochrisiko", punkte: 40 });
  }
  if (!lieferant.zertifikat) {
    punkte += 30;
    details.push({ kriterium: "Kein Nachhaltigkeitszertifikat vorhanden", punkte: 30 });
  }
  if (!lieferant.geodaten) {
    punkte += 20;
    details.push({ kriterium: "Geodaten fehlen", punkte: 20 });
  }
  if (hochrisikoProdukte.includes(lieferant.produkt)) {
    punkte += 10;
    details.push({ kriterium: "Produkt gehört zu Hochrisikokategorie", punkte: 10 });
  }
  if (lieferant.benutzerRisiken) {
    lieferant.benutzerRisiken.forEach((r) => {
      punkte += r.punkte;
      details.push(r);
    });
  }

  let stufe = "niedrig";
  if (punkte >= 60) stufe = "hoch";
  else if (punkte >= 30) stufe = "mittel";

  return { punkte, stufe, details };
}

export default function App() {
  const [tab, setTab] = useState<"uebersicht" | "produkte" | "risiken" | "lieferanten">("uebersicht");
  const [ausgewaehlterLieferant, setAusgewaehlterLieferant] = useState<Lieferant | null>(null);
  const [neuesRisiko, setNeuesRisiko] = useState<string>("");
  const [neuePunkte, setNeuePunkte] = useState<number>(0);

  const handleVorgefertigtHinzufuegen = (eintrag: RisikoEintrag) => {
    if (!ausgewaehlterLieferant) return;
    const neueRisiken = [...(ausgewaehlterLieferant.benutzerRisiken || []), eintrag];
    setAusgewaehlterLieferant({ ...ausgewaehlterLieferant, benutzerRisiken: neueRisiken });
  };

  const handleEigenesRisikoHinzufuegen = () => {
    if (!ausgewaehlterLieferant || !neuesRisiko || neuePunkte <= 0) return;
    const neues: RisikoEintrag = { kriterium: neuesRisiko, punkte: neuePunkte };
    const neueRisiken = [...(ausgewaehlterLieferant.benutzerRisiken || []), neues];
    setAusgewaehlterLieferant({ ...ausgewaehlterLieferant, benutzerRisiken: neueRisiken });
    setNeuesRisiko("");
    setNeuePunkte(0);
  };

  const handleRisikoLoeschen = (index: number) => {
    if (!ausgewaehlterLieferant || !ausgewaehlterLieferant.benutzerRisiken) return;
    const neueRisiken = [...ausgewaehlterLieferant.benutzerRisiken];
    neueRisiken.splice(index, 1);
    setAusgewaehlterLieferant({ ...ausgewaehlterLieferant, benutzerRisiken: neueRisiken });
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6 space-y-6">
      <h1 className="text-3xl font-bold text-blue-700">🌱 EUDR Dashboard – Handelshaus GmbH</h1>

      {!ausgewaehlterLieferant && (
        <div className="flex space-x-4">
          <button onClick={() => setTab("uebersicht")} className={`px-4 py-2 rounded ${tab === "uebersicht" ? "bg-blue-600 text-white" : "bg-white border"}`}>Übersicht</button>
          <button onClick={() => setTab("produkte")} className={`px-4 py-2 rounded ${tab === "produkte" ? "bg-blue-600 text-white" : "bg-white border"}`}>Produkte</button>
          <button onClick={() => setTab("risiken")} className={`px-4 py-2 rounded ${tab === "risiken" ? "bg-blue-600 text-white" : "bg-white border"}`}>Risiken</button>
          <button onClick={() => setTab("lieferanten")} className={`px-4 py-2 rounded ${tab === "lieferanten" ? "bg-blue-600 text-white" : "bg-white border"}`}>Lieferanten</button>
        </div>
      )}

      {!ausgewaehlterLieferant && tab === "uebersicht" && (
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">📊 Übersicht</h2>
          <p>Hier folgt die Übersicht mit z.B. Fortschritt und Risiko-Zusammenfassungen.</p>
        </div>
      )}

      {!ausgewaehlterLieferant && tab === "produkte" && (
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">📦 Produkte</h2>
          <ul className="list-disc ml-6">
            {lieferanten.map((l, i) => (
              <li key={i}>{l.produkt} – {l.name}</li>
            ))}
          </ul>
        </div>
      )}

      {!ausgewaehlterLieferant && tab === "risiken" && (
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">⚠️ Risikoübersicht</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={lieferanten.map(l => ({ name: l.name, risiko: berechneRisiko(l).punkte }))}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="risiko" fill="#e53e3e" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {!ausgewaehlterLieferant && tab === "lieferanten" && (
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-4">Lieferantenübersicht</h2>
          <table className="w-full text-left border">
            <thead>
              <tr className="bg-gray-200">
                <th className="p-2">Name</th>
                <th className="p-2">Produkt</th>
                <th className="p-2">Land</th>
                <th className="p-2">Kontinent</th>
                <th className="p-2">Risiko</th>
              </tr>
            </thead>
            <tbody>
              {lieferanten.map((l, i) => {
                const r = berechneRisiko(l);
                return (
                  <tr key={i} onClick={() => setAusgewaehlterLieferant(l)} className="border-t cursor-pointer hover:bg-gray-50">
                    <td className="p-2 font-medium">{l.name}</td>
                    <td className="p-2">{l.produkt}</td>
                    <td className="p-2">{l.land}</td>
                    <td className="p-2">{l.kontinent}</td>
                    <td className={`p-2 font-semibold ${r.stufe === "hoch" ? "text-red-600" : r.stufe === "mittel" ? "text-yellow-600" : "text-green-600"}`}>{r.stufe.toUpperCase()} ({r.punkte})</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {ausgewaehlterLieferant && (
        <div className="bg-white p-6 rounded-xl shadow space-y-6 border-t-4 border-blue-600">
          <h2 className="text-2xl font-bold text-blue-800">🔍 Risikoanalyse für {ausgewaehlterLieferant.name}</h2>
          <div className="grid grid-cols-2 gap-4 text-gray-700">
            <p><strong>📦 Produkt:</strong> {ausgewaehlterLieferant.produkt}</p>
            <p><strong>🌍 Land:</strong> {ausgewaehlterLieferant.land}</p>
            <p><strong>🌐 Kontinent:</strong> {ausgewaehlterLieferant.kontinent}</p>
            <p><strong>📍 Geodaten:</strong> {ausgewaehlterLieferant.geodaten || "Nicht vorhanden"}</p>
            <p><strong>✅ Zertifikat:</strong> {ausgewaehlterLieferant.zertifikat ? "Ja" : "Nein"}</p>
          </div>

          {(() => {
            const ergebnis = berechneRisiko(ausgewaehlterLieferant);
            return (
              <div className="space-y-4">
                <h3 className="text-xl font-semibold">📊 Risikobewertung</h3>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-600">Punkte:</span>
                  <span className="text-2xl font-bold">{ergebnis.punkte}</span>
                  <span className={`px-3 py-1 rounded-full text-white text-sm ${
                    ergebnis.stufe === "hoch" ? "bg-red-600" :
                    ergebnis.stufe === "mittel" ? "bg-yellow-500" :
                    "bg-green-600"
                  }`}>
                    {ergebnis.stufe.toUpperCase()}
                  </span>
                </div>
                <ul className="list-disc list-inside text-gray-800 space-y-1">
                  {ergebnis.details.map((item, idx) => (
                    <li key={idx}><strong>+{item.punkte}</strong> {item.kriterium}</li>
                  ))}
                </ul>
              </div>
            );
          })()}

          <h3 className="text-lg font-semibold mt-6">Benutzerdefinierte Risiken</h3>
          <ul className="list-disc ml-6">
            {ausgewaehlterLieferant.benutzerRisiken?.map((r, i) => (
              <li key={i}>{r.kriterium} (+{r.punkte}) <button className="text-red-600 ml-2" onClick={() => handleRisikoLoeschen(i)}>Löschen</button></li>
            ))}
          </ul>

          <div className="mt-4">
            <input type="text" placeholder="Neues Risiko" value={neuesRisiko} onChange={(e) => setNeuesRisiko(e.target.value)} className="border p-2 mr-2" />
            <input type="number" placeholder="Punkte" value={neuePunkte} onChange={(e) => setNeuePunkte(Number(e.target.value))} className="border p-2 mr-2 w-24" />
            <button onClick={handleEigenesRisikoHinzufuegen} className="bg-blue-600 text-white px-4 py-2 rounded">Hinzufügen</button>
          </div>

          <div className="mt-4">
            <h3 className="font-semibold">Vorgefertigte Risiken:</h3>
            {vorgefertigteRisiken.map((r, i) => (
              <button key={i} onClick={() => handleVorgefertigtHinzufuegen(r)} className="bg-gray-200 hover:bg-gray-300 px-3 py-1 rounded m-1 text-sm">
                {r.kriterium} (+{r.punkte})
              </button>
            ))}
          </div>

          <button onClick={() => setAusgewaehlterLieferant(null)} className="mt-6 px-4 py-2 bg-blue-600 text-white rounded shadow">
            🔙 Zurück zur Übersicht
          </button>
        </div>
      )}
    </div>
  );
}
